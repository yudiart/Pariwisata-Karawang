	
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?= base_url('vendor/purple/assets/vendors/js/vendor.bundle.base.js');?>"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?= base_url('vendor/purple/assets/js/off-canvas.js');?>"></script>
    <script src="<?= base_url('vendor/purple/assets/js/hoverable-collapse.js');?>"></script>
    <script src="<?= base_url('vendor/purple/assets/js/misc.js');?>"></script>
    <!-- endinject -->
  </body>
</html>	