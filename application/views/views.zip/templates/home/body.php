<div class="main-pannel-2">	
	<div class="container mb-6 ">
		<div class="box-panel-2">
			<div class="p-box-left pt-4" >
				<img src="<?= base_url('assets/image/1.png');?>" style="width:300px;">
			</div>
			<div class="p-box-right  pt-4 pr-2">
				<div class="p-box-right-col ">
					<h2><strong>Wisata Yuk</strong></h2>
						<div class="row">
					<div class="input-group col-lg-8">
							<input type="text" class="form-control " placeholder="Movie Title.." id="search-input">
							<div class="input-group-append">
								<button class="btn btn-outline-secondary" type="button" id="search-button">Button</button>
							</div>
						</div>							
					</div>
					<hr>
					<div class="row" id="movie-list">
					</div>
					<p style="text-align: justify;">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum..</p>
				</div>
			</div>
		</div>
	</div>
</div>	
