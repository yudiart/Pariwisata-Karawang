<!DOCTYPE>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <title><?= $title;?></title>

    <script src="<?= base_url('assets/js/script.js');?>"></script>
    <link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/style.css');?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    
   
        
    <link rel="stylesheet" href="<?= base_url('vendor/purple/assets/vendors/mdi/css/materialdesignicons.min.css');?>">
    <link rel="stylesheet" href="<?= base_url('vendor/purple/assets/vendors/css/vendor.bundle.base.css');?>">
    <!-- Layout styles -->
    <link rel="stylesheet" href="<?= base_url('vendor/purple/assets/css/style.css');?>">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="<?= base_url('assets/logo/logo.png');?>" />

    

  </head>
  <body>
    <div class="container-scroller">
        <div class="wrapper">