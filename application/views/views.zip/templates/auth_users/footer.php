<footer class="footer">
	<div class="d-sm-flex justify-content-center justify-content-sm-between">
	  <span class="text-muted  text-center text-sm-left d-block d-sm-inline-block">Copyright © <?= date('Y');?> <a href="https://www.vodonesia.id/" target="_blank" class="t-primary">Vodonesia Project</a>. All rights reserved.</span>
	  <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"><i class="mdi mdi-lock t-primary"></i><a href="https://www.termsfeed.com/privacy-policy/8e144a062a692c69eb029b013eb4450e" class="t-primary">Privacy Policy</a> </span>
	</div>
</footer>

<script src="<?= base_url('assets/js/script.js');?>"></script>

</html>